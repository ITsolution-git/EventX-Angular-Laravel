'use strict';

angular.module('eventx')
  .controller('DocCtrl', function ($scope) {
    $scope.message = 'Hello';
  });
