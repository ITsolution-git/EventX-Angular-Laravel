'use strict';

angular.module('eventx.admin', [
  'eventx.auth',
  'ui.router'
]);
