'use strict';

angular.module('eventx.util', []);
